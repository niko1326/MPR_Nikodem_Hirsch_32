package pl.edu.pjatk.WykladSpringJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WykladSpringJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WykladSpringJpaApplication.class, args);
	}

}
