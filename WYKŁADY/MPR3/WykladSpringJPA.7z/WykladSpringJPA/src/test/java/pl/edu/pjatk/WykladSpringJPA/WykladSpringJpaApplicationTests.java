package pl.edu.pjatk.WykladSpringJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WykladSpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
